import javax.swing.*;
import java.awt.image.BufferedImage;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.*;
import java.awt.Rectangle;
public class Player{
	private double x,y,velX=0,velY=0;
	private BufferedImageLoader loader;
	private BufferedImage player;
	Game game;
	public Player(double x,double y,Game game)
	{
		this.x=x;
		this.y=y;
		this.game=game;
		loader=game.getLoader();
		try{
		player=loader.loadImage("/playerImage.gif");
		}
		catch(Exception e)
		{
			System.out.println("Error in loading image");
		}
	}
	public void tick()
	{
		x+=velX;
		y+=velY;
		if(x<=0)
		x=0;
		if(y<=0)
		y=0;
		if(x>=750)
		x=750;
		if(y>=540)
		y=540;
		game.checkEnemy(this);
	}
	public Rectangle getBounds()
	{
		return new Rectangle((int)x,(int)y,36,26);
	}
	public void render(Graphics g)
	{
		g.drawImage(player,(int)x,(int)y,null);
	}
	public double getX()
	{
		return x;
	}
	public double getY()
	{
		return y;
	}
	public void setX(double x)
	{
		this.x=x;
	}
	public void setY(double y)
	{
		this.y=y;
	}
	public void setVelX(double x)
	{
		this.velX=x;
	}
	public void setVelY(double y)
	{
		this.velY=y;
	}
}
	

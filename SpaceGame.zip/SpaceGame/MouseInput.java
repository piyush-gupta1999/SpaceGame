import java.awt.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.*;
import java.awt.event.*;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
public class MouseInput implements MouseListener{
	
	public void mouseClicked(MouseEvent e) {
        }
        
     public void mouseEntered(MouseEvent e) {
     }
       
     public void mouseExited(MouseEvent e) {
     }
    	public void mousePressed(MouseEvent e)
	{
		int mx=(int)e.getX();
		int my=(int)e.getY();
		//Play Button
		if((mx>=Game.WIDTH/2+120)&&(mx<=Game.WIDTH/2+220))
		{
			if((my>=150)&&(my<=200))
			{
				Game.state=Game.state.GAME;
			}
				
		}
		//Help Button
		if((mx>=Game.WIDTH/2+120)&&(mx<=Game.WIDTH/2+220))
		{
			if((my>=250)&&(my<=300))
			{
				JFrame f;
				f=new JFrame();
				JOptionPane.showMessageDialog(f,"Hello,Welcome to Space Game Developed By Piyush Gupta.\nPress Play to Start the game.Keep away from ememies and shoot them using spacebar.\nMove your SpaceShip using arrow keys in four direction.\nFor any query mail me at guptapiyush963@gmail.com.\nPlay & Enjoy :)\n"); 
			}
				
		}
		//Quit Button
		if((mx>=Game.WIDTH/2+120)&&(mx<=Game.WIDTH/2+220))
		{
			if((my>=350)&&(my<=400))
			{
				System.exit(1);
			}
				
		}
		
	}      
     public void mouseReleased(MouseEvent e) {
     }
}

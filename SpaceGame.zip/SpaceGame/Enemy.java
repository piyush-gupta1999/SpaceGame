import java.awt.image.BufferedImage;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.*;
import java.awt.Rectangle;
public class Enemy{
	private double x,y;
	private BufferedImage image;
	private BufferedImageLoader loader;
	private Game game;
	private int speed=new Random().nextInt(5)+1;
	public Enemy(double x,double y,Game game)
	{
		this.x=x;
		this.y=y;
		this.game=game;
		loader=game.getLoader();
		try{
		int x1=new Random().nextInt(3);
		if(x1==1)
		image=loader.loadImage("/enemyImage.png");
		else if(x1==2)
		image=loader.loadImage("/enemyImage2.jpg");
		else
		image=loader.loadImage("/enemyImage3.jpg");
		}
		catch(Exception e)
		{
			System.out.println("Error in loading image");
		}
	}
	public void tick()
	{
		y+=speed;
		int v=new Random().nextInt(2);
		if(v==1)
		x-=speed;
		else
		x+=speed; 
		if(x<=0)
		x=10;
		if(y>Game.HEIGHT*Game.SCALE)
		{
			x=new Random().nextInt(675);
			y=-30;
			
		}
	}
	public Rectangle getBounds()
	{
		return new Rectangle((int)x,(int)y,37,35);
	}
	public void render(Graphics g)
	{
		
		g.drawImage(image,(int)x,(int)y,null);
	}
	public int getY()
	{	
		return (int)y;
	}
	public BufferedImage getImage()
	{
		return image;
	}
}

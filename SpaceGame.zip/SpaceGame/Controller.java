import java.util.LinkedList;
import java.awt.Graphics;
import java.awt.*;
import javax.swing.*;
import java.awt.image.BufferedImage;
import java.awt.image.BufferStrategy;
import java.util.*;
import java.awt.event.*;
import java.awt.Rectangle;
public class Controller{
	private LinkedList<Bullet> b=new LinkedList<Bullet>();
	private LinkedList<Enemy> e=new LinkedList<Enemy>();
	Enemy TempEnemy;
	Bullet TempBullet;
	Game game;
	public Controller(Game g)
	{
		this.game=game;
	}
	public void createEnemy(int enemyCount,Game game)
	{
		int i;
		for(i=0;i<enemyCount;i++)
		{
			addEnemy(new Enemy(new Random().nextInt(675),-10,game));
		}
	}
	public void tick()
	{
		int i;
		for(i=0;i<b.size();i++)
		{
			TempBullet =b.get(i);
			if(TempBullet.getY()<0)
			removeBullet(TempBullet);
			TempBullet.tick();
		}
		
		for(i=0;i<e.size();i++)
		{
			TempEnemy=e.get(i);
			TempEnemy.tick();
		}
	}
	public void render(Graphics g)
	{
		int i;
		for(i=0;i<b.size();i++)
		{
			TempBullet =b.get(i);
			TempBullet.draw(g);
		}
		
		for(i=0;i<e.size();i++)
		{
			TempEnemy =e.get(i);
			TempEnemy.render(g);
		}
	}
	public void addBullet(Bullet block)
	{
		b.add(block);
	}
	public void removeBullet(Bullet block)
	{
		b.remove(block);
	}
	public void addEnemy(Enemy block)
	{
		e.add(block);
	}
	public void removeEnemy(Enemy block)
	{
		e.remove(block);
	}
	public LinkedList<Enemy> getEnemyList()
	{
		return e;
	}
	public LinkedList<Bullet> getBulletList()
	{
		return b;
	}
	
	
}

import java.awt.*;
import javax.swing.*;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.*;
import java.awt.event.*;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.Graphics2D;
import java.net.URL;
//import javafx.animation;
import java.awt.EventQueue;
import javax.swing.JFrame;
public class Animation{
	private BufferedImage img1,img2,img3,img4,img5,img;
	int speed;
	public Animation(int speed,BufferedImage b1,BufferedImage b2,BufferedImage b3,BufferedImage b4,BufferedImage b5)
	{
		this.speed=speed;
		img1=b1;
		img2=b2;
		img3=b3;
		img4=b4;
		img5=b5;
	}
	public void runAnimation()
	{
		Random v=new Random();
		int r=v.nextInt(5);
		if(r==0)
		img=img1;
		else if(r==1)
		img=img2;
		else if(r==2)
		img=img3;
		else if(r==3)
		img=img4;
		else 
		img=img5;
	}
	public void drawAnimation(Graphics g,int x,int y,int width,int height)
	{
		speed--;
		if(speed==0)
		{
			g.drawImage(img,0,0,width,height,null);
			speed=2;
		}
	}
	
}	

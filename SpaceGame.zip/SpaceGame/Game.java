import java.awt.*;
import javax.swing.*;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.*;
import java.awt.event.*;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.Graphics2D;
import java.net.URL;
import java.awt.EventQueue;
import javax.swing.JFrame;
import java.io.*; 

public class Game extends Canvas implements Runnable{

	public static final int WIDTH=400;
	public static final int HEIGHT=WIDTH/12*9;
	public static final int SCALE=2;
	public final String TITLE="2D Space Game";
	public static int score=0,health=100,highScore=0;
	private Player p;
	private boolean running=false;
	private Thread thread;
	private BufferedImage image=new BufferedImage(WIDTH,HEIGHT,BufferedImage.TYPE_INT_RGB);
	private BufferedImage[] background;
	private BufferedImageLoader loader,backgroundLoader;
	private Controller c;
	private Font font;
	private int enemyCount=6,enemyKilled=0;
	private boolean is_shooting;
	private Menu menu;
	public static LinkedList<Enemy> enemyList;
	public static LinkedList<Bullet> bulletList;
	public static enum STATE{
	MENU,
	GAME
	};
	public static STATE state=STATE.MENU;
	private void init()
	{
		menu=new Menu();
		font=new Font("arial",Font.BOLD,20);
		loader=new BufferedImageLoader();
		backgroundLoader=new BufferedImageLoader();
		p=new Player(320,620,this);	
		c=new Controller(this);
		addKeyListener(new KeyInput(this));
		this.addMouseListener(new MouseInput());
		int i;
		c.createEnemy(enemyCount,this);
		enemyList=c.getEnemyList();
		bulletList=c.getBulletList();
		background=new BufferedImage[1];
		try{
		FileReader fr = new FileReader("HighScore.txt");  
    		highScore=fr.read(); 
      	if(highScore==-1)
      	highScore=0;
      	fr.close();
		}catch(Exception e)
		{
			System.out.println("Error");
		}
	}
	public synchronized void start()
	{
		if(running)
		return;
		running=true;
		thread =new Thread(this);
		thread.start();
	}
	public void run()
	{
		//Update our game at every second
		init();
		
		long lastTime=System.nanoTime();
		final double amountOfTicks=60;
		double ns=1000000000/amountOfTicks;
		double delta=0;
		int updates=0;
		int frames=0;
		long timer=System.currentTimeMillis();
		while(running)
		{
			//Game Loop
			long now=System.nanoTime();
			delta+=(now-lastTime)/ns;
			lastTime=now;
			if(delta>=1)
			{
				tick();
				updates++;
				delta=0;
			}
			render();
			frames++;
			if(System.currentTimeMillis()-timer>1000)
			{
				timer+=1000;
				updates=0;
				frames=0;
			}	
			
			
			
		}
		stop();
	}
	private void tick()
	{
		if(state==STATE.GAME){
			p.tick();
			c.tick();
			if(enemyKilled==enemyCount)
			{
				enemyCount=new Random().nextInt(10);
				enemyKilled=0;
				c.createEnemy(enemyCount,this);
			}
		}
	}
	private void render()
	{
		BufferStrategy bs=this.getBufferStrategy();
		if(bs==null)
		{
			createBufferStrategy(3);
			return;
		}
		
		Graphics g=bs.getDrawGraphics();
		g.drawImage(image,0,0,getWidth(),getHeight(),this);
		g.drawImage(background[0],0,0,getWidth(),getHeight(),null);
		if(state==STATE.GAME){
		try{
		background[0]=backgroundLoader.loadImage("/background.gif");
		}
		catch(Exception e)
		{
			System.out.println("Error in loading image");
		}
		p.render(g);
		c.render(g);
			
			g.setFont(font);
			g.setColor(Color.white);
			g.drawString("Score="+score,10,20);
			g.drawString("Health="+health,590,20);
			g.drawString("High Score="+highScore,10,50);
		}else if(state==STATE.MENU){
			menu.render(g);		
		}
		///////////////////////////
		g.dispose();
		bs.show();
	}
	public synchronized void stop()
	{
		if(!running)
		return;
		running=false;
		try{
			JFrame f;
			int a;
			f=new JFrame();
			if(score>highScore)
			{
				highScore=score;
				a=JOptionPane.showConfirmDialog(f,"Congratulation you created High Score "+score+ "\nDo you want to Play Again.");
                    String high_score=""+highScore;
                    BufferedWriter writer = new BufferedWriter(new FileWriter("HighScore.txt"));
    				writer.write(high_score);
    				writer.close();
			}else
			{
				a=JOptionPane.showConfirmDialog(f,"Game over your Score is "+score+ "\nDo you want to Play Again.");
			}
			if(a==JOptionPane.YES_OPTION){  
    				f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    				running=true;
    				score=0;
    				health=100;
    				enemyKilled=0;
    				init();  
			}else
			{
				running=true;
    				score=0;
    				health=100;
    				enemyKilled=0;
    				init();  
				state=STATE.MENU;
			}
   
			//thread.join();
		}catch(Exception E)
		{
			E.printStackTrace();
		}
		//System.exit(1);
	}
	
	public void keyPressed(KeyEvent e)
	{
		int key=e.getKeyCode();
		if(state==STATE.GAME){
		
			if(key==KeyEvent.VK_RIGHT)
			{
				p.setVelX(10.0);
			}else if(key==KeyEvent.VK_LEFT)
			{
				p.setVelX(-10.0);
			}else if(key==KeyEvent.VK_DOWN)
			{
				p.setVelY(10.0);
			}else if(key==KeyEvent.VK_UP)
			{
				p.setVelY(-10.0);
			}else if((key==KeyEvent.VK_SPACE)&&(!is_shooting))
			{
				is_shooting=true;
				//Audio audio=new Audio();
				//audio.sound("/shoot.mp3");
				c.addBullet(new Bullet(p.getX(),p.getY(),this));
			}	
		}
			
	}
	
	public void keyReleased(KeyEvent e)
	{
		int key=e.getKeyCode();
		if(key==KeyEvent.VK_RIGHT)
		{ 
			p.setVelX(0);
		}else if(key==KeyEvent.VK_LEFT)
		{
			p.setVelX(0);
		}else if(key==KeyEvent.VK_DOWN)
		{
			p.setVelY(0);
		}else if(key==KeyEvent.VK_UP)
		{
			p.setVelY(0);
		}else if(key==KeyEvent.VK_SPACE)
		{
			is_shooting=false;
			
		}
	}
	
	public static void main(String args[])
	{
		Game game=new Game();
		game.setPreferredSize(new Dimension(WIDTH*SCALE,HEIGHT*SCALE));
		game.setMaximumSize(new Dimension(WIDTH*SCALE,HEIGHT*SCALE));
		game.setMinimumSize(new Dimension(WIDTH*SCALE,HEIGHT*SCALE));
		
		JFrame frame=new JFrame(game.TITLE);
		frame.add(game);
		frame.pack();
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.setLocationRelativeTo(null);
		game.start();
		
	}
	public BufferedImageLoader getLoader()
	{
		return loader;
	}
	public int getEnemyCount()
	{
		return enemyCount;
	}
	public void setEnemyCount(int enemyCount)
	{
		this.enemyCount=enemyCount;
	}
	public int getEnemyKilled()
	{
		return enemyKilled;
	}
	public void setEnemyKilled(int enemyKilled)
	{
		this.enemyKilled=enemyKilled;
	}
	public void checkBullet(Bullet bullet)
	{
		int i;
		for(i=0;i<c.getEnemyList().size();i++)
		{
			if(bullet.getBounds().intersects(c.getEnemyList().get(i).getBounds()))
			{
				c.removeBullet(bullet);
				c.removeEnemy(c.getEnemyList().get(i));
				enemyKilled++;
				score++;
				break;
			}
		}
	}
	public void checkEnemy(Player p)
	{
		
		int i;
		for(i=0;i<c.getEnemyList().size();i++)
		{
			if(p.getBounds().intersects(c.getEnemyList().get(i).getBounds()))
			{
				c.removeEnemy(c.getEnemyList().get(i));
				enemyKilled++;
				health-=10;
				if(health<=0)
				{
					stop();
				}
				break;
			}
		}
	}	
}

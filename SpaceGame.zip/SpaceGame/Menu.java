import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.*;
import java.net.URL;
import java.awt.*;
public class Menu{
	public Rectangle playButton=new Rectangle(Game.WIDTH/2+120,150,100,50);
	public Rectangle helpButton=new Rectangle(Game.WIDTH/2+120,250,100,50);
	public Rectangle quitButton=new Rectangle(Game.WIDTH/2+120,350,100,50);
	public void render(Graphics g)
	{
		Graphics2D g2d=(Graphics2D)g;
		
		Font font=new Font("arial",Font.BOLD,50);
		g.setFont(font);
		g.setColor(Color.white);
		g.drawString("Space Game",Game.WIDTH/2,100);
		Font font1=new Font("arial",Font.BOLD,23);
		g.setFont(font1);
		g.drawString("Play",playButton.x+22,playButton.y+38);
		g2d.draw(playButton);
		g.drawString("Help",helpButton.x+22,helpButton.y+38);
		g2d.draw(helpButton);
		g.drawString("Quit",quitButton.x+22,quitButton.y+38);
		g2d.draw(quitButton);
	}
}

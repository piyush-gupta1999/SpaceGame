import java.awt.image.BufferedImage;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.Rectangle;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.*;
import java.net.URL;
import java.awt.*;
public class Bullet{
	private double x,y;
	private BufferedImage image;
	private BufferedImageLoader loader;
	Game game;
	public Bullet(double x,double y,Game game)
	{
		this.x=x;
		this.y=y;
		this.game=game;
		loader=game.getLoader();
		try{
		image=loader.loadImage("/bullet1.jpg");
		}
		catch(Exception e)
		{
			System.out.println("Error in loading image");
		}
	}
	public void tick()
	{
		y-=12;
		game.checkBullet(this);		
	}
	public void draw(Graphics g)
	{
		g.drawImage(image,(int)x,(int)y,null);
		
	}
	public Rectangle getBounds()
	{
		return new Rectangle((int)x,(int)y,35,24);
	}
	public int getY()
	{	
		return (int)y;
	}
	
}
